import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import 'app_core.dart';

/// Admin/developer tool for authenticated HLS/DASH packaging and thumbnail
/// previews. This does not itself provision a CDN or a DRM license server.
class StreamingDeliveryStudioScreen extends StatefulWidget {
  const StreamingDeliveryStudioScreen({super.key});

  @override
  State<StreamingDeliveryStudioScreen> createState() => _StreamingDeliveryStudioScreenState();
}

class _StreamingDeliveryStudioScreenState extends State<StreamingDeliveryStudioScreen> {
  final _pathController = TextEditingController();
  final _secondsController = TextEditingController(text: '60');
  String _format = 'hls';
  bool _working = false;
  String? _error;
  String? _status;
  Map<String, dynamic>? _capabilities;
  Uint8List? _thumbnailBytes;
  String? _manifestUrl;
  List<String> _fallbackUrls = [];
  VideoPlayerController? _player;
  String? _playerError;

  @override
  void initState() {
    super.initState();
    unawaited(_loadCapabilities());
  }

  @override
  void dispose() {
    _pathController.dispose();
    _secondsController.dispose();
    _player?.dispose();
    super.dispose();
  }

  Future<void> _loadCapabilities() async {
    try {
      final data = await AppController.instance.backendApi.getPlaybackCapabilities();
      if (mounted) setState(() => _capabilities = data);
    } catch (error) {
      if (mounted) setState(() => _error = 'Playback capability check: ${_clean(error)}');
    }
  }

  String _clean(Object error) => error.toString().replaceFirst('BackendApiException:', '').replaceFirst('Exception: ', '').trim();

  String _absoluteBackendPath(String path) {
    final uri = Uri.parse(AppController.instance.backendApi.baseUrl);
    return '${uri.scheme}://${uri.authority}${path.startsWith('/') ? path : '/$path'}';
  }

  Future<void> _generateThumbnail() async {
    final path = _pathController.text.trim();
    final seconds = double.tryParse(_secondsController.text.trim());
    if (path.isEmpty || seconds == null || !seconds.isFinite || seconds < 0) {
      setState(() => _error = 'Provide a relative media path and a non-negative timestamp.');
      return;
    }
    setState(() { _working = true; _error = null; _status = 'Generating thumbnail on the media server…'; });
    try {
      final result = await AppController.instance.backendApi.generateSmartThumbnail(path: path, seconds: seconds);
      final encoded = result['imageBase64']?.toString() ?? '';
      if (encoded.isEmpty) throw StateError('The server returned no thumbnail data.');
      if (mounted) setState(() { _thumbnailBytes = base64Decode(encoded); _status = 'Generated thumbnail at ${seconds.toStringAsFixed(1)} seconds.'; });
    } catch (error) {
      if (mounted) setState(() => _error = _clean(error));
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _prepareAdaptive() async {
    final path = _pathController.text.trim();
    if (path.isEmpty) {
      setState(() => _error = 'Enter a relative media path under the backend MEDIA_ROOT.');
      return;
    }
    setState(() { _working = true; _error = null; _status = 'Packaging adaptive renditions with FFmpeg…'; _playerError = null; });
    try {
      final result = await AppController.instance.backendApi.prepareAdaptivePlayback(path: path, format: _format);
      final pathFromServer = result['manifestPath']?.toString() ?? '';
      if (pathFromServer.isEmpty) throw StateError('The server did not return a manifest URL.');
      final cdnUrls = (result['cdnMirrorPaths'] as List? ?? const []).map((item) => item.toString()).where((value) => Uri.tryParse(value)?.scheme == 'https').toList();
      final originUrl = _absoluteBackendPath(pathFromServer);
      _player?.dispose();
      _player = null;
      setState(() {
        _manifestUrl = originUrl;
        _fallbackUrls = [...cdnUrls.where((url) => url != originUrl)];
        _status = '${_format.toUpperCase()} manifest ready. Capability expires ${result['expiresAt'] ?? 'after a short period'}.';
      });
    } catch (error) {
      if (mounted) setState(() => _error = _clean(error));
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _playAdaptive() async {
    final url = _manifestUrl;
    if (url == null) return;
    final candidates = <String>[url, ..._fallbackUrls];
    final backend = AppController.instance.backendApi;
    final headers = backend.token == null ? <String, String>{} : {'Authorization': 'Bearer ${backend.token}'};
    setState(() { _working = true; _playerError = null; _status = 'Trying origin and configured CDN URLs…'; });
    for (final candidate in candidates) {
      VideoPlayerController? attempt;
      try {
        final uri = Uri.tryParse(candidate);
        if (uri == null || !{'https', 'http'}.contains(uri.scheme) || uri.host.isEmpty) continue;
        attempt = VideoPlayerController.networkUrl(uri, httpHeaders: headers);
        await attempt.initialize().timeout(const Duration(seconds: 45));
        await attempt.setLooping(false);
        if (!mounted) { await attempt.dispose(); return; }
        final old = _player;
        setState(() { _player = attempt; _status = 'Playback initialized from ${uri.host}.'; _working = false; });
        if (old != null) await old.dispose();
        return;
      } catch (error) {
        await attempt?.dispose();
        _playerError = _clean(error);
      }
    }
    if (mounted) setState(() => _playerError = 'Playback failed on the origin and configured CDN URLs. ${_playerError ?? ''}'.trim());
    if (mounted) setState(() => _working = false);
  }

  @override
  Widget build(BuildContext context) {
    final player = _player;
    final drm = _capabilities?['drm'] is Map ? Map<String, dynamic>.from(_capabilities!['drm'] as Map) : const <String, dynamic>{};
    final cdnConfigured = _capabilities?['multiCdnConfigured'] == true;
    final recommendations = AppController.instance.recommendations;
    return Scaffold(
      appBar: AppBar(title: const Text('AI discovery & delivery')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Personalized discovery uses the app’s profile-aware recommendation engine, which scores available titles from library metadata and viewing preferences. Thumbnail generation extracts a frame at a chosen timestamp from media you are authorized to access; automatic visual ranking/generative thumbnail selection still requires a configured AI vision provider.', style: TextStyle(color: Colors.white70, height: 1.4)),
          const SizedBox(height: 14),
          Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Personalized picks (${recommendations.length})', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            if (recommendations.isEmpty) const Text('No recommendations loaded yet. Sign in and refresh recommendations after building your profile history.'),
            ...recommendations.take(8).map((item) => ListTile(dense: true, contentPadding: EdgeInsets.zero, leading: const Icon(Icons.auto_awesome_rounded), title: Text(item.title), subtitle: Text('${item.releaseYear ?? 'Year unknown'} • ${item.type} • ${item.genres.take(3).join(', ')}'))),
          ]))),
          const SizedBox(height: 16),
          Text('Media server tools', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 6),
          TextField(controller: _pathController, enabled: !_working, decoration: const InputDecoration(labelText: 'Relative media path', hintText: 'Movies/Example.mkv', helperText: 'Resolved under MEDIA_ROOT; absolute paths are rejected.', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: TextField(controller: _secondsController, enabled: !_working, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Thumbnail timestamp (seconds)', border: OutlineInputBorder()))),
            const SizedBox(width: 10),
            FilledButton.icon(onPressed: _working ? null : _generateThumbnail, icon: const Icon(Icons.photo_camera_back_rounded), label: const Text('Thumbnail')),
          ]),
          if (_thumbnailBytes != null) ...[
            const SizedBox(height: 12),
            ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.memory(_thumbnailBytes!, fit: BoxFit.contain, height: 210)),
          ],
          const SizedBox(height: 18),
          SegmentedButton<String>(
            segments: const [ButtonSegment(value: 'hls', label: Text('HLS'), icon: Icon(Icons.video_library_outlined)), ButtonSegment(value: 'dash', label: Text('DASH'), icon: Icon(Icons.high_quality_outlined))],
            selected: {_format},
            onSelectionChanged: _working ? null : (selection) => setState(() => _format = selection.first),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(onPressed: _working ? null : _prepareAdaptive, icon: const Icon(Icons.hd_rounded), label: Text('Create adaptive ${_format.toUpperCase()} package')),
          if (_manifestUrl != null) ...[
            const SizedBox(height: 10),
            SelectableText('Origin manifest: $_manifestUrl'),
            if (_fallbackUrls.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text('CDN candidates (${_fallbackUrls.length}):', style: Theme.of(context).textTheme.titleSmall),
              ..._fallbackUrls.map((url) => SelectableText(url, style: const TextStyle(fontSize: 12, color: Colors.white60))),
            ],
            const SizedBox(height: 10),
            OutlinedButton.icon(onPressed: _working ? null : _playAdaptive, icon: const Icon(Icons.play_arrow_rounded), label: const Text('Test adaptive playback / CDN fallback')),
            if (player != null && player.value.isInitialized) ...[
              const SizedBox(height: 10),
              AspectRatio(aspectRatio: player.value.aspectRatio == 0 ? 16 / 9 : player.value.aspectRatio, child: VideoPlayer(player)),
              VideoProgressIndicator(player, allowScrubbing: true),
              Align(alignment: Alignment.center, child: IconButton(iconSize: 42, onPressed: () => setState(() => player.value.isPlaying ? player.pause() : player.play()), icon: Icon(player.value.isPlaying ? Icons.pause_circle : Icons.play_circle))),
            ],
          ],
          if (_working) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
          if (_status != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_status!, style: const TextStyle(color: Colors.lightGreenAccent))),
          if (_error != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_error!, style: const TextStyle(color: Colors.redAccent))),
          if (_playerError != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_playerError!, style: const TextStyle(color: Colors.orangeAccent))),
          const SizedBox(height: 18),
          Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Delivery and protection status', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            _statusRow('Adaptive HLS/DASH packaging', _capabilities?['adaptiveBitrate'] == true),
            _statusRow('Multi-CDN bases configured', cdnConfigured),
            _statusRow('Widevine license URL configured', drm['widevineConfigured'] == true),
            _statusRow('FairPlay license URL configured', drm['fairplayConfigured'] == true),
            _statusRow('PlayReady license URL configured', drm['playreadyConfigured'] == true),
            const SizedBox(height: 8),
            const Text('A configured license URL alone does not activate DRM. Commercial DRM requires a licensed encrypting packager, entitlement checks, a license proxy, platform-specific player SDKs, and provider credentials. CDNs must actually mirror or proxy the origin package before their links will work.', style: TextStyle(color: Colors.white70, height: 1.35)),
          ]))),
        ],
      ),
    );
  }

  Widget _statusRow(String label, bool active) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(children: [Icon(active ? Icons.check_circle_outline : Icons.info_outline, size: 18, color: active ? Colors.lightGreenAccent : Colors.white54), const SizedBox(width: 8), Expanded(child: Text(label)), Text(active ? 'Ready' : 'Not configured', style: TextStyle(color: active ? Colors.lightGreenAccent : Colors.white54, fontSize: 12))]),
  );
}
