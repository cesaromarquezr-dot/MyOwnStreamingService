import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'activity_timeline.dart';
import 'actor_connections.dart';
import 'app_core.dart';
import 'details.dart';
import 'feature_center.dart';
import 'group_watch.dart';
import 'home_server.dart';
import 'library_privacy.dart';
import 'music_achievements.dart';
import 'streaming_delivery_studio.dart';
import 'offline_downloads.dart';
import 'profile_content_safety.dart';
import 'profiles.dart';
import 'remote_access.dart';
import 'security_settings.dart';
import 'smart_search.dart';
import 'social_center.dart';
import 'storage_dashboard.dart';
import 'xray.dart';

/// One entry point for the social, discovery, profile-safety, and home-server
/// capabilities that are otherwise spread across the application.
class StreamingCompanionHubScreen extends StatelessWidget {
  const StreamingCompanionHubScreen({super.key});

  void _push(BuildContext context, Widget page) => Navigator.of(context).push<void>(
        MaterialPageRoute<void>(builder: (_) => page),
      );

  Future<void> _openXray(BuildContext context) async {
    final items = AppController.instance.library;
    if (items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Add media to the library before opening X-Ray.')),
      );
      return;
    }
    final selected = await showModalBottomSheet<MediaItem>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        child: SizedBox(
          height: MediaQuery.sizeOf(sheetContext).height * .68,
          child: ListView(
            children: [
              const ListTile(title: Text('Choose media for X-Ray and spoiler protection')),
              ...items.map((item) => ListTile(
                    leading: const Icon(Icons.movie_outlined),
                    title: Text(item.title),
                    subtitle: Text('${item.releaseYear ?? 'Year unknown'} • ${item.type}'),
                    onTap: () => Navigator.pop(sheetContext, item),
                  )),
            ],
          ),
        ),
      ),
    );
    if (selected == null || !context.mounted) return;
    _push(context, _XRayLaunchScreen(media: selected));
  }

  @override
  Widget build(BuildContext context) {
    final controller = AppController.instance;
    final profile = controller.currentProfile;
    final libraryCount = controller.library.length;
    final friendStatus = controller.backendApi.isAuthenticated ? 'Connected account' : 'Sign in to sync';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Streaming Companion'),
        actions: [
          IconButton(
            tooltip: 'Search the library',
            onPressed: () => _push(context, const SmartSearchScreen()),
            icon: const Icon(Icons.search_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 30),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const LinearGradient(
                colors: [Color(0xFF272D43), Color(0xFF15171D)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(color: Colors.white12),
            ),
            child: Row(
              children: [
                const CircleAvatar(
                  radius: 27,
                  backgroundColor: Color(0xFF39435E),
                  child: Icon(Icons.movie_filter_rounded, size: 29),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(profile == null ? 'Your streaming space' : 'Welcome, ${profile.name}',
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 4),
                      Text('$libraryCount media items • $friendStatus',
                          style: const TextStyle(color: Colors.white70, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _section('Social & watch together', 'Share the experience with friends and family.'),
          _FeatureTile(
            icon: Icons.people_alt_rounded,
            title: 'Friends, communities, chat & posts',
            subtitle: 'Feed, DMs, stories, GIF/video sharing, message reactions and communities.',
            onTap: () => _push(context, const SocialCenterScreen()),
          ),
          _FeatureTile(
            icon: Icons.groups_rounded,
            title: 'Watch Together',
            subtitle: 'Create a synchronized watch session, invite profiles and open its live controls.',
            onTap: () => _push(context, const GroupWatchLauncherScreen()),
          ),
          _FeatureTile(
            icon: Icons.history_rounded,
            title: 'Activity timeline',
            subtitle: 'Review profile-scoped viewing and interaction activity from the backend.',
            onTap: profile == null
                ? () => _signInMessage(context)
                : () => _push(context, ActivityHistoryScreen(profileId: profile.id)),
          ),
          _FeatureTile(
            icon: Icons.favorite_outline_rounded,
            title: 'Shared group watchlist',
            subtitle: 'Review suggestions shared by the account, remove items or add a selection to the library.',
            onTap: () => _push(context, const SharedWatchlistScreen()),
          ),
          _FeatureTile(
            icon: Icons.collections_bookmark_rounded,
            title: 'Collections & recommendation voting',
            subtitle: 'Manage collections and review the recommendation / voting panels.',
            onTap: () => _push(context, const FeatureCenterScreen()),
          ),
          const SizedBox(height: 18),
          _section('Discover & personalize', 'Find your next watch and keep track of your favorites.'),
          _FeatureTile(
            icon: Icons.search_rounded,
            title: 'Smart search',
            subtitle: 'Search titles and available indexed metadata.',
            onTap: () => _push(context, const SmartSearchScreen()),
          ),
          _FeatureTile(
            icon: Icons.account_tree_rounded,
            title: 'Actor, singer & collaborator connections',
            subtitle: 'Explore the shortest credited-person connection through items in your library.',
            onTap: () => _push(context, const ActorConnectionScreen()),
          ),
          _FeatureTile(
            icon: Icons.emoji_events_rounded,
            title: 'Achievements & viewing milestones',
            subtitle: 'Music, movie and TV collection achievements.',
            onTap: () => _push(context, const AchievementsScreen()),
          ),
          _FeatureTile(
            icon: Icons.query_stats_rounded,
            title: 'Profile statistics',
            subtitle: 'Open the active profile’s viewing and library statistics.',
            onTap: profile == null
                ? () => _signInMessage(context)
                : () => showModalBottomSheet<void>(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: Colors.transparent,
                      builder: (_) => ProfileStatisticsSheet(profile: profile),
                    ),
          ),
          _FeatureTile(
            icon: Icons.visibility_off_rounded,
            title: 'X-Ray & spoiler protection',
            subtitle: 'Choose a title to inspect credits, connections and spoiler-protection settings.',
            onTap: () => _openXray(context),
          ),
          _FeatureTile(
            icon: Icons.offline_pin_rounded,
            title: 'Offline library snapshot',
            subtitle: 'Cache profile-scoped media metadata locally for browsing during outages.',
            onTap: () => _push(context, const OfflineLibrarySnapshotScreen()),
          ),
          _FeatureTile(
            icon: Icons.download_for_offline_rounded,
            title: 'Offline media downloads',
            subtitle: 'Download authorized direct media files to app-private storage for playback without a network connection.',
            onTap: () => _push(context, const OfflineDownloadsScreen()),
          ),
          _FeatureTile(
            icon: Icons.hd_rounded,
            title: 'AI discovery & streaming delivery',
            subtitle: 'View personalized picks, generate preview thumbnails, package HLS/DASH, test playback, and inspect CDN/DRM readiness.',
            onTap: () => _push(context, const StreamingDeliveryStudioScreen()),
          ),
          const SizedBox(height: 18),
          _section('Server, storage & profile safety', 'Tools for keeping the home server usable and access appropriately restricted.'),
          _FeatureTile(
            icon: Icons.dns_rounded,
            title: 'Home server & library scan',
            subtitle: 'Check server status, storage, ARM and run the existing scan-and-sync workflow.',
            onTap: () => _push(context, const HomeServerScreen()),
          ),
          _FeatureTile(
            icon: Icons.storage_rounded,
            title: 'Storage dashboard',
            subtitle: 'View and configure the app storage dashboard.',
            onTap: () => _push(context, const StorageDashboardScreen()),
          ),
          _FeatureTile(
            icon: Icons.security_rounded,
            title: 'Content and parental controls',
            subtitle: 'Configure restrictions for the active profile.',
            onTap: profile == null
                ? () => _signInMessage(context)
                : () => _push(context, ProfileContentSafetyScreen(profile: profile)),
          ),
          _FeatureTile(
            icon: Icons.shield_outlined,
            title: 'Account security',
            subtitle: 'Review security posture, MFA and authenticated sessions.',
            onTap: () => _push(context, const SecuritySettingsScreen()),
          ),
          _FeatureTile(
            icon: Icons.lock_outline_rounded,
            title: 'Library privacy',
            subtitle: 'Review your library privacy and account deletion options.',
            onTap: () => _push(context, const LibraryPrivacyScreen()),
          ),
          _FeatureTile(
            icon: Icons.router_rounded,
            title: 'Remote access & trusted devices',
            subtitle: 'Review the existing remote-access workflow and access guidance.',
            onTap: () => _push(context, const RemoteAccessScreen()),
          ),
        ],
      ),
    );
  }

  Widget _section(String title, String subtitle) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          const SizedBox(height: 3),
          Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 12)),
        ]),
      );

  void _signInMessage(BuildContext context) => ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Select a profile and sign in to use this feature.')),
      );
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 8),
        color: const Color(0xFF171920),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          leading: Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: .06), borderRadius: BorderRadius.circular(13)),
            child: Icon(icon, color: const Color(0xFF9DD9F0)),
          ),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 3),
            child: Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 12, height: 1.3)),
          ),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: onTap,
        ),
      );
}

class ActivityHistoryScreen extends StatelessWidget {
  const ActivityHistoryScreen({super.key, required this.profileId});
  final String profileId;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Activity timeline')),
        body: ActivityTimeline(profileId: profileId, limit: 100),
      );
}

class GroupWatchLauncherScreen extends StatefulWidget {
  const GroupWatchLauncherScreen({super.key});

  @override
  State<GroupWatchLauncherScreen> createState() => _GroupWatchLauncherScreenState();
}

class _GroupWatchLauncherScreenState extends State<GroupWatchLauncherScreen> {
  String? _selectedMediaId;
  final Set<String> _invitedProfileIds = <String>{};
  bool _working = false;
  String? _error;

  @override
  Widget build(BuildContext context) {
    final controller = AppController.instance;
    final items = controller.library;
    final profile = controller.currentProfile;
    final otherProfiles = (controller.currentAccount?.profiles ?? const <Profile>[])
        .where((p) => p.id != profile?.id).toList();
    MediaItem? selected;
    for (final item in items) {
      if (item.id == _selectedMediaId) {
        selected = item;
        break;
      }
    }
    selected ??= items.isEmpty ? null : items.first;
    final selectedMedia = selected;
    return Scaffold(
      appBar: AppBar(title: const Text('Watch Together')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Choose a title to start a synchronized session. Playback state and participant controls use the existing authenticated backend API.', style: TextStyle(color: Colors.white70, height: 1.4)),
          const SizedBox(height: 16),
          const Text('Choose a movie or show', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          const SizedBox(height: 8),
          if (items.isEmpty)
            const Card(child: ListTile(title: Text('Your library is empty'), subtitle: Text('Import media or scan the server first.')))
          else
            ...items.map((item) => Card(
                  child: RadioListTile<String>(
                    value: item.id,
                    groupValue: selectedMedia?.id,
                    onChanged: (value) => setState(() => _selectedMediaId = value),
                    title: Text(item.title),
                    subtitle: Text('${item.releaseYear ?? 'Year unknown'} • ${item.type}'),
                    secondary: item.imageUrl != null && item.imageUrl!.startsWith('http')
                        ? ClipRRect(borderRadius: BorderRadius.circular(6), child: CachedNetworkImage(imageUrl: item.imageUrl!, width: 42, height: 60, fit: BoxFit.cover, errorWidget: (_, __, ___) => const Icon(Icons.movie_outlined)))
                        : const Icon(Icons.movie_outlined),
                  ),
                )),
          if (otherProfiles.isNotEmpty) ...[
            const SizedBox(height: 10),
            const Text('Invite profiles in this account', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
            const SizedBox(height: 4),
            const Text('Invitations are sent through the backend. Profiles outside this account can be invited from the app’s friend/invitation flows.', style: TextStyle(color: Colors.white54, fontSize: 12)),
            ...otherProfiles.map((p) => CheckboxListTile(
                  value: _invitedProfileIds.contains(p.id),
                  onChanged: (value) => setState(() {
                    if (value == true) {
                      _invitedProfileIds.add(p.id);
                    } else {
                      _invitedProfileIds.remove(p.id);
                    }
                  }),
                  title: Text(p.name),
                  controlAffinity: ListTileControlAffinity.leading,
                )),
          ],
          if (_error != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(_error!, style: const TextStyle(color: Colors.redAccent))),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _working || selectedMedia == null ? null : () => _start(selectedMedia),
            icon: _working ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.play_circle_fill_rounded),
            label: Text(_working ? 'Creating session…' : 'Create watch session'),
          ),
        ],
      ),
    );
  }

  Future<void> _start(MediaItem media) async {
    final controller = AppController.instance;
    if (!controller.backendApi.isAuthenticated || controller.currentProfile == null) {
      setState(() => _error = 'Sign in and select a profile before creating a watch session.');
      return;
    }
    setState(() { _working = true; _error = null; });
    try {
      final session = await controller.createBackendGroupWatchSession(
        media,
        invitedProfileIds: _invitedProfileIds.isEmpty ? null : _invitedProfileIds,
      );
      if (!mounted) return;
      await Navigator.of(context).push<void>(MaterialPageRoute<void>(
        builder: (_) => GroupWatchScreen(media: media, sessionId: session.id),
      ));
    } catch (error) {
      if (mounted) setState(() => _error = error.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }
}

class SharedWatchlistScreen extends StatefulWidget {
  const SharedWatchlistScreen({super.key});

  @override
  State<SharedWatchlistScreen> createState() => _SharedWatchlistScreenState();
}

class _SharedWatchlistScreenState extends State<SharedWatchlistScreen> {
  bool _loading = true;
  String? _error;
  final Set<String> _busyItems = <String>{};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    final controller = AppController.instance;
    try {
      await controller.loadGroupWishlist();
      if (controller.groupWishlistError != null) throw Exception(controller.groupWishlistError);
    } catch (error) {
      _error = error.toString().replaceFirst('Exception: ', '');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _runItemAction(String id, Future<void> Function() action) async {
    if (!_busyItems.add(id)) return;
    setState(() {});
    try {
      await action();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Shared watchlist updated.')));
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString().replaceFirst('Exception: ', ''))));
    } finally {
      _busyItems.remove(id);
      if (mounted) setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = AppController.instance;
    final profile = controller.currentProfile;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Shared group watchlist'),
        actions: [IconButton(onPressed: _loading ? null : _load, tooltip: 'Refresh', icon: const Icon(Icons.refresh_rounded))],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : !controller.backendApi.isAuthenticated
              ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Sign in to load the shared group watchlist.', textAlign: TextAlign.center)))
              : _error != null
                  ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [Text(_error!, textAlign: TextAlign.center), const SizedBox(height: 12), FilledButton(onPressed: _load, child: const Text('Try again'))])))
                  : controller.wishlist.isEmpty
                      ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.favorite_border_rounded, size: 54), SizedBox(height: 10), Text('No shared watchlist items yet.', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)), SizedBox(height: 6), Text('Approved recommendations can appear here for everyone in the account.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60))])))
                      : ListView.separated(
                          padding: const EdgeInsets.all(16),
                          itemCount: controller.wishlist.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (context, index) {
                            final item = controller.wishlist[index];
                            final busy = _busyItems.contains(item.id);
                            return ListTile(
                              leading: CircleAvatar(child: Icon(item.type.toLowerCase().contains('show') || item.type.toLowerCase().contains('series') ? Icons.tv_rounded : Icons.movie_outlined)),
                              title: Text(item.title),
                              subtitle: Text(item.type),
                              trailing: PopupMenuButton<String>(
                                enabled: !busy,
                                onSelected: (action) {
                                  if (action == 'remove') {
                                    _runItemAction(item.id, () async {
                                      await controller.removeFromGroupWishlist(item.id);
                                      await controller.loadGroupWishlist();
                                    });
                                  } else if (action == 'add') {
                                    if (profile == null) {
                                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select a profile first.')));
                                      return;
                                    }
                                    _runItemAction(item.id, () => controller.acquireGroupWishlistItem(mediaId: item.id, profileId: profile.id));
                                  }
                                },
                                itemBuilder: (_) => const [
                                  PopupMenuItem(value: 'add', child: Text('Add to my library')),
                                  PopupMenuItem(value: 'remove', child: Text('Remove from shared list')),
                                ],
                                child: busy ? const Padding(padding: EdgeInsets.all(12), child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))) : const Icon(Icons.more_vert_rounded),
                              ),
                            );
                          },
                        ),
    );
  }
}

class OfflineLibrarySnapshotScreen extends StatefulWidget {
  const OfflineLibrarySnapshotScreen({super.key});

  @override
  State<OfflineLibrarySnapshotScreen> createState() => _OfflineLibrarySnapshotScreenState();
}

class _OfflineLibrarySnapshotScreenState extends State<OfflineLibrarySnapshotScreen> {
  List<MediaItem> _cached = <MediaItem>[];
  DateTime? _cachedAt;
  bool _loading = true;
  bool _saving = false;
  String? _error;

  String get _key {
    final profileId = AppController.instance.currentProfile?.id ?? 'guest';
    return 'offline_media_snapshot_v1_$profileId';
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_key);
      final decoded = raw == null ? null : jsonDecode(raw);
      final items = decoded is List
          ? decoded.whereType<Map>().map((m) => MediaItem.fromJson(Map<String, dynamic>.from(m))).toList()
          : <MediaItem>[];
      final rawDate = prefs.getString('${_key}_timestamp');
      if (!mounted) return;
      setState(() {
        _cached = items;
        _cachedAt = rawDate == null ? null : DateTime.tryParse(rawDate);
        _loading = false;
        _error = null;
      });
    } catch (error) {
      if (mounted) setState(() { _loading = false; _error = 'Could not read the local snapshot: $error'; });
    }
  }

  Future<void> _saveSnapshot() async {
    setState(() { _saving = true; _error = null; });
    try {
      final prefs = await SharedPreferences.getInstance();
      final controller = AppController.instance;
      final profile = controller.currentProfile;
      final items = profile == null
          ? <MediaItem>[]
          : controller.library.where((item) => item.isAccessibleTo(profile)).take(2000).toList();
      if (items.isEmpty && profile == null) {
        throw StateError('Select a profile before caching its library.');
      }
      final compactRecords = items.map((item) => <String, dynamic>{
        'id': item.id,
        'title': item.title,
        'type': item.type,
        'imageUrl': item.imageUrl,
        'description': item.description,
        'releaseYear': item.releaseYear,
        'rating': item.rating,
        'ratingReason': item.ratingReason,
        'addedAt': item.addedAt.toIso8601String(),
        'actors': item.actors.take(30).toList(),
        'directors': item.directors.take(15).toList(),
        'writers': item.writers.take(15).toList(),
        'music': item.music.take(20).toList(),
        'genres': item.genres.take(20).toList(),
        'tags': item.tags.take(40).toList(),
        'franchiseName': item.franchiseName,
        'franchiseType': item.franchiseType,
      }).toList();
      await prefs.setString(_key, jsonEncode(compactRecords));
      final timestamp = DateTime.now();
      await prefs.setString('${_key}_timestamp', timestamp.toIso8601String());
      if (!mounted) return;
      setState(() { _cached = List<MediaItem>.from(items); _cachedAt = timestamp; });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Cached metadata for ${items.length} accessible items on this device.')));
    } catch (error) {
      if (mounted) setState(() => _error = 'Snapshot failed: $error');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _clearSnapshot() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
    await prefs.remove('${_key}_timestamp');
    if (mounted) setState(() { _cached = <MediaItem>[]; _cachedAt = null; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Offline library snapshot')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('This stores a profile-scoped copy of media metadata on this device so titles, cast, genres and descriptions remain browsable when the server is temporarily unavailable. It does not download or make video/audio files playable offline.', style: TextStyle(color: Colors.white70, height: 1.4)),
                  const SizedBox(height: 10),
                  Text(_cachedAt == null ? 'No snapshot saved yet.' : 'Last snapshot: ${_cachedAt!.toLocal()}', style: const TextStyle(color: Colors.white54, fontSize: 12)),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: FilledButton.icon(onPressed: _saving ? null : _saveSnapshot, icon: const Icon(Icons.download_for_offline_rounded), label: Text(_saving ? 'Caching…' : 'Cache current library'))),
                    const SizedBox(width: 8),
                    IconButton(tooltip: 'Delete snapshot', onPressed: _cached.isEmpty ? null : _clearSnapshot, icon: const Icon(Icons.delete_outline_rounded)),
                  ]),
                  if (_error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_error!, style: const TextStyle(color: Colors.redAccent))),
                ]),
              ),
              const Divider(height: 1),
              Expanded(child: _cached.isEmpty
                  ? const Center(child: Text('Your saved offline snapshot will appear here.'))
                  : ListView.separated(
                      itemCount: _cached.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, index) {
                        final media = _cached[index];
                        return ListTile(
                          leading: media.imageUrl != null && media.imageUrl!.startsWith('http')
                              ? CachedNetworkImage(imageUrl: media.imageUrl!, width: 45, height: 64, fit: BoxFit.cover, errorWidget: (_, __, ___) => const Icon(Icons.movie_outlined))
                              : const Icon(Icons.movie_outlined),
                          title: Text(media.title),
                          subtitle: Text('${media.releaseYear ?? 'Year unknown'} • ${media.type} • ${media.genres.take(2).join(', ')}'),
                          onTap: () => Navigator.of(context).push<void>(MaterialPageRoute<void>(builder: (_) => MediaDetailsScreen(media: media))),
                        );
                      },
                    )),
            ]),
    );
  }
}

class _XRayLaunchScreen extends StatefulWidget {
  const _XRayLaunchScreen({required this.media});
  final MediaItem media;

  @override
  State<_XRayLaunchScreen> createState() => _XRayLaunchScreenState();
}

class _XRayLaunchScreenState extends State<_XRayLaunchScreen> {
  final ValueNotifier<Duration> _position = ValueNotifier<Duration>(Duration.zero);

  @override
  void dispose() {
    _position.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => XRayScreen(media: widget.media, playbackPosition: _position);
}
