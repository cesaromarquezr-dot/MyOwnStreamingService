import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Device-bound encryption for text-only social messages.
///
/// Uses X25519 + HKDF-SHA256 + AES-256-GCM. The private key is held in
/// FlutterSecureStorage and never uploaded. This intentionally does not claim
/// forward secrecy or protection from server-side public-key substitution:
/// verify the displayed key fingerprints out-of-band for sensitive chats.
class SocialE2eeService {
  SocialE2eeService._();

  static const String marker = 'moss-e2ee-v1';
  static const FlutterSecureStorage _storage = FlutterSecureStorage();
  static final X25519 _keyExchange = X25519();
  static final AesGcm _cipher = AesGcm.with256bits();
  static final Hkdf _kdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);

  static String _privateKeyStorageKey(String profileId) =>
      'moss_e2ee_x25519_private_v1_${base64Url.encode(utf8.encode(profileId)).replaceAll('=', '')}';

  static Future<_DeviceIdentity> _identity(String profileId) async {
    final cleanProfile = profileId.trim();
    if (cleanProfile.isEmpty) throw ArgumentError('A profile ID is required.');
    final saved = await _storage.read(key: _privateKeyStorageKey(cleanProfile));
    late final SimpleKeyPair keyPair;
    if (saved != null && saved.isNotEmpty) {
      final privateBytes = base64Decode(saved);
      if (privateBytes.length != 32) {
        await _storage.delete(key: _privateKeyStorageKey(cleanProfile));
        throw StateError('The stored encryption key is invalid. Regenerate the profile key.');
      }
      keyPair = await _keyExchange.newKeyPairFromSeed(privateBytes);
    } else {
      keyPair = await _keyExchange.newKeyPair();
      final privateBytes = await keyPair.extractPrivateKeyBytes();
      await _storage.write(
        key: _privateKeyStorageKey(cleanProfile),
        value: base64Encode(privateBytes),
      );
    }
    final publicKey = await keyPair.extractPublicKey();
    return _DeviceIdentity(keyPair, base64Encode(publicKey.bytes));
  }

  static Future<String> publicKeyForProfile(String profileId) async =>
      (await _identity(profileId)).publicKey;

  static String fingerprint(String base64PublicKey) {
    try {
      final bytes = base64Decode(base64PublicKey);
      final digest = sha256.convert(bytes).toString().toUpperCase();
      return RegExp('.{1,4}').allMatches(digest).map((match) => match.group(0)).join(' ');
    } catch (_) {
      return 'Invalid key';
    }
  }

  static Future<String> encryptForMembers({
    required String profileId,
    required String conversationId,
    required String plaintext,
    required List<Map<String, dynamic>> members,
  }) async {
    final senderId = profileId.trim();
    final identity = await _identity(senderId);
    final recipientKeys = <String, String>{senderId: identity.publicKey};
    for (final member in members) {
      final recipientId = (member['profileId'] ?? member['profile_id'])?.toString().trim() ?? '';
      if (recipientId.isEmpty || recipientId == senderId) continue;
      final publicKey = (member['e2eePublicKey'] ?? member['e2ee_public_key'])?.toString().trim() ?? '';
      if (publicKey.isEmpty) {
        final label = member['display_name']?.toString() ?? member['username']?.toString() ?? 'A chat member';
        throw StateError('$label must open this conversation once to enable end-to-end encryption.');
      }
      recipientKeys[recipientId] = publicKey;
    }
    if (recipientKeys.length < 2) {
      throw StateError('End-to-end encryption needs every other chat member to open the chat once and publish a key.');
    }

    final recipientEnvelopes = <String, dynamic>{};
    for (final entry in recipientKeys.entries) {
      final recipientId = entry.key;
      final publicBytes = base64Decode(entry.value);
      if (publicBytes.length != 32) {
        throw StateError('A chat member has an invalid encryption public key.');
      }
      final remotePublicKey = SimplePublicKey(publicBytes, type: KeyPairType.x25519);
      final sharedSecret = await _keyExchange.sharedSecretKey(
        keyPair: identity.keyPair,
        remotePublicKey: remotePublicKey,
      );
      final info = utf8.encode('MyOwnStreamingService E2EE v1|$senderId|$recipientId');
      final encryptionKey = await _kdf.deriveKey(
        secretKey: sharedSecret,
        nonce: utf8.encode(conversationId),
        info: info,
      );
      final aad = utf8.encode('$conversationId|$senderId|$recipientId');
      final box = await _cipher.encrypt(
        utf8.encode(plaintext),
        secretKey: encryptionKey,
        aad: aad,
      );
      recipientEnvelopes[recipientId] = {
        'nonce': base64Encode(box.nonce),
        'cipherText': base64Encode(box.cipherText),
        'mac': base64Encode(box.mac.bytes),
      };
    }
    final encodedPayload = jsonEncode({
      'type': marker,
      'version': 1,
      'conversationId': conversationId,
      'senderProfileId': senderId,
      'senderPublicKey': identity.publicKey,
      'recipientEnvelopes': recipientEnvelopes,
    });
    if (encodedPayload.length > 59000) {
      throw StateError('This conversation is too large for the current encrypted-message size limit.');
    }
    return encodedPayload;
  }

  static bool isEncryptedEnvelope(Object? body) {
    if (body is! String || body.length > 60000) return false;
    try {
      final decoded = jsonDecode(body);
      return decoded is Map && decoded['type'] == marker && decoded['version'] == 1;
    } catch (_) {
      return false;
    }
  }

  static Future<String> decryptForProfile({
    required String profileId,
    required String conversationId,
    required String envelopeText,
  }) async {
    final decoded = jsonDecode(envelopeText);
    if (decoded is! Map || decoded['type'] != marker || decoded['version'] != 1) {
      return envelopeText;
    }
    final envelope = Map<String, dynamic>.from(decoded);
    if (envelope['conversationId']?.toString() != conversationId) {
      throw StateError('Encrypted message conversation mismatch.');
    }
    final recipientId = profileId.trim();
    final recipients = envelope['recipientEnvelopes'];
    if (recipients is! Map || recipients[recipientId] is! Map) {
      throw StateError('This message was not encrypted for this profile or its device key is missing.');
    }
    final senderId = envelope['senderProfileId']?.toString() ?? '';
    final senderPublicBase64 = envelope['senderPublicKey']?.toString() ?? '';
    final senderPublicBytes = base64Decode(senderPublicBase64);
    if (senderId.isEmpty || senderPublicBytes.length != 32) {
      throw StateError('Encrypted message public key is invalid.');
    }
    final identity = await _identity(recipientId);
    final sharedSecret = await _keyExchange.sharedSecretKey(
      keyPair: identity.keyPair,
      remotePublicKey: SimplePublicKey(senderPublicBytes, type: KeyPairType.x25519),
    );
    final info = utf8.encode('MyOwnStreamingService E2EE v1|$senderId|$recipientId');
    final encryptionKey = await _kdf.deriveKey(
      secretKey: sharedSecret,
      nonce: utf8.encode(conversationId),
      info: info,
    );
    final recipientBox = Map<String, dynamic>.from(recipients[recipientId] as Map);
    final box = SecretBox(
      base64Decode(recipientBox['cipherText']?.toString() ?? ''),
      nonce: base64Decode(recipientBox['nonce']?.toString() ?? ''),
      mac: Mac(base64Decode(recipientBox['mac']?.toString() ?? '')),
    );
    final clearText = await _cipher.decrypt(
      box,
      secretKey: encryptionKey,
      aad: utf8.encode('$conversationId|$senderId|$recipientId'),
    );
    return utf8.decode(clearText);
  }
}

class _DeviceIdentity {
  const _DeviceIdentity(this.keyPair, this.publicKey);
  final SimpleKeyPair keyPair;
  final String publicKey;
}
